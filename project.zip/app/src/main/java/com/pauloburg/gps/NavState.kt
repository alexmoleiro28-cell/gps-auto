package com.pauloburg.gps

import org.json.JSONObject

/** État du guidage, envoyé par la page (JavaScript) et lu par l'écran de la voiture. */
object NavState {
    @Volatile var on = false
    @Volatile var dist = 0
    @Volatile var text = ""
    @Volatile var street = ""
    @Volatile var man = "straight"
    @Volatile var exit = 1
    @Volatile var next = ""
    @Volatile var remKm = 0.0
    @Volatile var remMin = 0
    @Volatile var etaMs = 0L
    @Volatile var toll = ""
    @Volatile var limit = 0
    @Volatile var speed = 0
    @Volatile var cy = 0.62

    @Volatile var listener: (() -> Unit)? = null
    @Volatile var onStop: (() -> Unit)? = null

    fun update(json: String) {
        val o = JSONObject(json)
        on = o.optBoolean("on", false)
        dist = o.optInt("dist", 0)
        text = o.optString("text", "")
        street = o.optString("street", "")
        man = o.optString("man", "straight")
        exit = o.optInt("exit", 1)
        next = o.optString("next", "")
        remKm = o.optDouble("remKm", 0.0)
        remMin = o.optInt("remMin", 0)
        etaMs = o.optLong("etaMs", 0L)
        toll = o.optString("toll", "")
        limit = o.optInt("limit", 0)
        speed = o.optInt("speed", 0)
        cy = o.optDouble("cy", 0.62)
        listener?.invoke()
    }
}
