package com.pauloburg.gps

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.Surface
import androidx.car.app.AppManager
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.DateTimeWithZone
import androidx.car.app.model.Distance
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import androidx.car.app.navigation.NavigationManager
import androidx.car.app.navigation.NavigationManagerCallback
import androidx.car.app.navigation.model.Maneuver
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.navigation.model.RoutingInfo
import androidx.car.app.navigation.model.Step
import androidx.car.app.navigation.model.TravelEstimate
import androidx.car.app.validation.HostValidator
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import java.util.TimeZone

/** Service Android Auto : guidage + recopie de l'écran du téléphone sur l'écran de la voiture. */
class GpsCarAppService : CarAppService() {
    override fun createHostValidator(): HostValidator {
        NavState.hostAt = System.currentTimeMillis()
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    }

    override fun onCreateSession(): Session = GpsSession()
}

class GpsSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen {
        NavState.sessionAt = System.currentTimeMillis()
        return GpsScreen(carContext)
    }
}

class GpsScreen(carContext: CarContext) : Screen(carContext) {
    private val handler = Handler(Looper.getMainLooper())
    private var lastKey = ""
    private var navStarted = false
    private var surface: Surface? = null
    private var surfW = 0
    private var surfH = 0
    private var visible: Rect? = null
    private var mode = 0 // 0 = carte plein écran, 1 = écran entier, 2 = infos
    private var srcTop = 0f
    private var mirrorFail = 0
    private var busy = false
    private var running = false
    private var bmp: Bitmap? = null
    private var dst: RectF? = null
    private var scale = 1f
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val navManager: NavigationManager = carContext.getCarService(NavigationManager::class.java)

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            frame()
            handler.postDelayed(this, 130)
        }
    }

    init {
        navManager.setNavigationManagerCallback(object : NavigationManagerCallback {
            override fun onStopNavigation() {
                NavState.onStop?.invoke()
            }

            override fun onAutoDriveEnabled() {}
        })
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(object : SurfaceCallback {
            override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
                surface = surfaceContainer.surface
                surfW = surfaceContainer.width
                surfH = surfaceContainer.height
                running = true
                handler.removeCallbacks(tick)
                handler.post(tick)
            }

            override fun onVisibleAreaChanged(visibleArea: Rect) {
                visible = Rect(visibleArea)
            }

            override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
                running = false
                surface = null
                handler.removeCallbacks(tick)
            }

            override fun onClick(x: Float, y: Float) {
                tap(x, y)
            }

            override fun onScroll(distanceX: Float, distanceY: Float) {
                drag(distanceX, distanceY)
            }
        })
        NavState.listener = { handler.post { refresh() } }
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                running = false
                NavState.listener = null
                handler.removeCallbacksAndMessages(null)
            }
        })
    }

    private fun refresh() {
        val s = NavState
        val key = "${s.on}|${s.dist / 10}|${s.text}|${s.street}|${s.man}|${s.remMin}|${s.remKm}|${s.next}|$mode"
        if (key != lastKey) {
            lastKey = key
            invalidate()
        }
    }

    // ---------- recopie de l'écran du téléphone ----------

    private fun capture(done: (Bitmap?) -> Unit) {
        val act = MainActivity.instance
        val v = act?.webView
        if (act == null || v == null || v.width <= 0 || v.height <= 0 || !v.isShown) {
            done(null)
            return
        }
        var b = bmp
        if (b == null || b.width != v.width || b.height != v.height) {
            b = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
            bmp = b
        }
        val target: Bitmap = b!!
        if (Build.VERSION.SDK_INT >= 26) {
            val loc = IntArray(2)
            v.getLocationInWindow(loc)
            try {
                PixelCopy.request(
                    act.window,
                    Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height),
                    target,
                    { result -> done(if (result == PixelCopy.SUCCESS) target else null) },
                    handler
                )
            } catch (e: Exception) {
                done(null)
            }
        } else {
            act.runOnUiThread {
                try {
                    v.draw(Canvas(target))
                    handler.post { done(target) }
                } catch (e: Exception) {
                    handler.post { done(null) }
                }
            }
        }
    }

    private fun frame() {
        if (busy) return
        val sf = surface ?: return
        if (!sf.isValid) return
        if (!NavState.on || mode == 2) {
            drawInfo()
            return
        }
        busy = true
        capture { b ->
            if (b != null) {
                mirrorFail = 0
                drawMirror(b, mode == 0)
            } else {
                mirrorFail++
                drawInfo()
            }
            busy = false
        }
    }

    private fun drawMirror(b: Bitmap, fill: Boolean) {
        val sf = surface ?: return
        if (!sf.isValid) return
        val canvas: Canvas? = try {
            sf.lockCanvas(null)
        } catch (e: Exception) {
            null
        }
        if (canvas == null) return
        try {
            canvas.drawColor(Color.BLACK)
            val cw = canvas.width.toFloat()
            val ch = canvas.height.toFloat()
            if (fill) {
                // la carte remplit tout l'écran : on prend une bande du téléphone, centrée autour de la flèche
                val srcW = b.width.toFloat()
                val srcH = Math.min(b.height.toFloat(), srcW * ch / cw)
                val carY = (NavState.cy.toFloat().coerceIn(0.2f, 0.9f)) * b.height
                var top = carY - 0.72f * srcH
                if (top < 0f) top = 0f
                if (top > b.height - srcH) top = b.height - srcH
                srcTop = top
                scale = cw / srcW
                dst = RectF(0f, 0f, cw, ch)
                canvas.drawBitmap(b, Rect(0, top.toInt(), b.width, (top + srcH).toInt()), dst!!, paint)
            } else {
                var area = RectF(0f, 0f, cw, ch)
                val vis = visible
                if (vis != null && vis.width() > 200 && vis.height() > 120) area = RectF(vis)
                val sc = Math.min(area.width() / b.width, area.height() / b.height)
                val w = b.width * sc
                val h = b.height * sc
                val left = area.centerX() - w / 2
                val top = area.centerY() - h / 2
                srcTop = 0f
                scale = sc
                dst = RectF(left, top, left + w, top + h)
                canvas.drawBitmap(b, null, dst!!, paint)
            }
        } finally {
            sf.unlockCanvasAndPost(canvas)
        }
    }

    // ---------- appuis sur l'écran de la voiture -> transmis à la page ----------

    private fun toView(x: Float, y: Float): PointF? {
        val d = dst ?: return null
        if (scale <= 0f) return null
        return PointF((x - d.left) / scale, (y - d.top) / scale + srcTop)
    }

    private fun tap(x: Float, y: Float) {
        val p = toView(x, y) ?: return
        val v = MainActivity.instance?.webView ?: return
        val t0 = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t0, t0, MotionEvent.ACTION_DOWN, p.x, p.y, 0)
        v.dispatchTouchEvent(down)
        down.recycle()
        handler.postDelayed({
            val up = MotionEvent.obtain(t0, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, p.x, p.y, 0)
            v.dispatchTouchEvent(up)
            up.recycle()
        }, 70)
    }

    private var dragOn = false
    private var dragX = 0f
    private var dragY = 0f
    private var dragT0 = 0L
    private val dragUp = Runnable {
        val v = MainActivity.instance?.webView
        if (v != null && dragOn) {
            val up = MotionEvent.obtain(dragT0, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, dragX, dragY, 0)
            v.dispatchTouchEvent(up)
            up.recycle()
        }
        dragOn = false
    }

    private fun drag(distanceX: Float, distanceY: Float) {
        val v = MainActivity.instance?.webView ?: return
        if (scale <= 0f) return
        if (!dragOn) {
            dragOn = true
            dragX = v.width / 2f
            dragY = v.height / 2f
            dragT0 = SystemClock.uptimeMillis()
            val down = MotionEvent.obtain(dragT0, dragT0, MotionEvent.ACTION_DOWN, dragX, dragY, 0)
            v.dispatchTouchEvent(down)
            down.recycle()
        }
        dragX -= distanceX / scale
        dragY -= distanceY / scale
        val move = MotionEvent.obtain(dragT0, SystemClock.uptimeMillis(), MotionEvent.ACTION_MOVE, dragX, dragY, 0)
        v.dispatchTouchEvent(move)
        move.recycle()
        handler.removeCallbacks(dragUp)
        handler.postDelayed(dragUp, 220)
    }

    // ---------- guidage officiel Android Auto ----------

    private fun maneuver(key: String, exit: Int): Maneuver {
        val pair = when (key) {
            "right" -> Pair(Maneuver.TYPE_TURN_NORMAL_RIGHT, R.drawable.man_right)
            "left" -> Pair(Maneuver.TYPE_TURN_NORMAL_LEFT, R.drawable.man_left)
            "slight_right" -> Pair(Maneuver.TYPE_TURN_SLIGHT_RIGHT, R.drawable.man_slight_right)
            "slight_left" -> Pair(Maneuver.TYPE_TURN_SLIGHT_LEFT, R.drawable.man_slight_left)
            "sharp_right" -> Pair(Maneuver.TYPE_TURN_SHARP_RIGHT, R.drawable.man_sharp_right)
            "sharp_left" -> Pair(Maneuver.TYPE_TURN_SHARP_LEFT, R.drawable.man_sharp_left)
            "uturn" -> Pair(Maneuver.TYPE_U_TURN_LEFT, R.drawable.man_uturn)
            "roundabout" -> Pair(Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CCW, R.drawable.man_roundabout)
            "arrive" -> Pair(Maneuver.TYPE_DESTINATION, R.drawable.man_arrive)
            "depart" -> Pair(Maneuver.TYPE_DEPART, R.drawable.man_depart)
            else -> Pair(Maneuver.TYPE_STRAIGHT, R.drawable.man_straight)
        }
        val b = Maneuver.Builder(pair.first)
            .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, pair.second)).build())
        if (pair.first == Maneuver.TYPE_ROUNDABOUT_ENTER_AND_EXIT_CCW) {
            b.setRoundaboutExitNumber(if (exit < 1) 1 else exit)
        }
        return b.build()
    }

    override fun onGetTemplate(): Template {
        val s = NavState
        if (!s.on) {
            if (navStarted) {
                navManager.navigationEnded()
                navStarted = false
            }
            return MessageTemplate.Builder("Lance un itinéraire dans l’appli GPS sur ton téléphone : l’écran apparaîtra ici.")
                .setTitle("GPS")
                .setHeaderAction(Action.APP_ICON)
                .build()
        }
        if (!navStarted) {
            navManager.navigationStarted()
            navStarted = true
        }
        val cue = if (s.text.isEmpty()) "Continuez" else s.text
        val step = Step.Builder(cue)
            .setRoad(if (s.street.isEmpty()) cue else s.street)
            .setManeuver(maneuver(s.man, s.exit))
            .build()
        val dist = if (s.dist >= 1000) {
            Distance.create(s.dist / 1000.0, Distance.UNIT_KILOMETERS_P1)
        } else {
            Distance.create((if (s.dist < 10) 10 else (s.dist / 10) * 10).toDouble(), Distance.UNIT_METERS)
        }
        val routing = RoutingInfo.Builder().setCurrentStep(step, dist)
        if (s.next.isNotEmpty()) {
            routing.setNextStep(Step.Builder("Puis").setManeuver(maneuver(s.next, 1)).build())
        }
        val est = TravelEstimate.Builder(
            Distance.create(s.remKm, Distance.UNIT_KILOMETERS_P1),
            DateTimeWithZone.create(s.etaMs, TimeZone.getDefault())
        ).setRemainingTimeSeconds(s.remMin * 60L).build()
        return NavigationTemplate.Builder()
            .setNavigationInfo(routing.build())
            .setDestinationTravelEstimate(est)
            .setActionStrip(
                ActionStrip.Builder()
                    .addAction(
                        Action.Builder()
                            .setTitle("Arrêter")
                            .setOnClickListener { NavState.onStop?.invoke() }
                            .build()
                    )
                    .addAction(
                        Action.Builder()
                            .setTitle(if (mode == 0) "Écran" else if (mode == 1) "Infos" else "Carte")
                            .setOnClickListener {
                                mode = (mode + 1) % 3
                                lastKey = ""
                                refresh()
                            }
                            .build()
                    )
                    .build()
            )
            .setMapActionStrip(ActionStrip.Builder().addAction(Action.PAN).build())
            .build()
    }

    /** Vue de secours : vitesse, limitation et péages (quand la recopie n'est pas possible). */
    private fun drawInfo() {
        val sf = surface ?: return
        if (!sf.isValid) return
        val canvas: Canvas? = try {
            sf.lockCanvas(null)
        } catch (e: Exception) {
            null
        }
        if (canvas == null) return
        try {
            canvas.drawColor(Color.rgb(16, 22, 30))
            val w = canvas.width.toFloat()
            val h = canvas.height.toFloat()
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.typeface = Typeface.DEFAULT_BOLD
            p.textAlign = Paint.Align.CENTER
            val s = NavState
            if (!s.on) {
                p.color = Color.WHITE
                p.textSize = h * 0.12f
                canvas.drawText("GPS", w / 2, h / 2, p)
                return
            }
            p.color = Color.WHITE
            p.textSize = h * 0.30f
            canvas.drawText(s.speed.toString(), w / 2, h * 0.52f, p)
            p.color = Color.LTGRAY
            p.textSize = h * 0.07f
            canvas.drawText("km/h", w / 2, h * 0.62f, p)
            if (s.limit > 0) {
                val cx = w * 0.82f
                val cy = h * 0.30f
                val r = h * 0.14f
                p.style = Paint.Style.FILL
                p.color = Color.WHITE
                canvas.drawCircle(cx, cy, r, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = r * 0.22f
                p.color = Color.rgb(217, 32, 42)
                canvas.drawCircle(cx, cy, r, p)
                p.style = Paint.Style.FILL
                p.color = Color.BLACK
                p.textSize = r * 0.95f
                canvas.drawText(s.limit.toString(), cx, cy + r * 0.32f, p)
            }
            if (s.toll.isNotEmpty()) {
                p.color = Color.rgb(180, 160, 255)
                p.textSize = h * 0.07f
                canvas.drawText("Péages " + s.toll, w / 2, h * 0.80f, p)
            }
            if (mode != 2 && mirrorFail > 0) {
                p.color = Color.rgb(255, 200, 80)
                p.textSize = h * 0.045f
                canvas.drawText("Garde l’appli ouverte et l’écran du téléphone allumé pour la recopie", w / 2, h * 0.92f, p)
            }
        } finally {
            sf.unlockCanvasAndPost(canvas)
        }
    }
}
