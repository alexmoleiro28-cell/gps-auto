package com.pauloburg.gps

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.speech.RecognizerIntent
import android.view.KeyEvent
import android.provider.ContactsContract
import android.os.SystemClock
import android.media.AudioManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var wv: WebView
    private var loaded = false

    /** Utilisé par l'écran de la voiture pour recopier la page. */
    val webView: WebView get() = wv

    companion object {
        @Volatile
        var instance: MainActivity? = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        wv = WebView(this)
        wv.keepScreenOn = true
        setContentView(wv)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setGeolocationEnabled(true)
        s.mediaPlaybackRequiresUserGesture = false
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith("https://gps.local")) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                }
                return true
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                callback.invoke(origin, true, false)
            }
        }
        NavState.onStop = { runOnUiThread { wv.evaluateJavascript("endNav()", null) } }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            load()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        }
    }


    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data != null) {
            val r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (r != null && r.size > 0) {
                wv.evaluateJavascript("window.__voice&&window.__voice(" + JSONObject.quote(r[0]) + ")", null)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        load()
    }

    private fun load() {
        if (loaded) return
        loaded = true
        try {
            val html = assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            wv.loadDataWithBaseURL("https://gps.local/", html, "text/html", "utf-8", null)
        } catch (e: Exception) {
            wv.loadData("Erreur : " + e.message, "text/plain", "utf-8")
        }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (wv.canGoBack()) wv.goBack() else super.onBackPressed()
    }

    /** Relais entre la page et le téléphone / la voiture. */
    private inner class Bridge {
        @JavascriptInterface
        fun listen() {
            runOnUiThread {
                try {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Dis ta destination ou une commande")
                    startActivityForResult(i, 77)
                } catch (e: Exception) {
                    wv.evaluateJavascript("window.showToast&&showToast('🎤 Reconnaissance vocale indisponible sur ce téléphone', 3500)", null)
                }
            }
        }

        @JavascriptInterface
        fun openApp(pkg: String, uri: String, fallback: String) {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
                i.setPackage(pkg)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return
            } catch (e: Exception) {
            }
            try {
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                    return
                }
            } catch (e: Exception) {
            }
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(fallback))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun mediaKey(code: Int) {
            try {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val t = SystemClock.uptimeMillis()
                am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
                am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun dial(number: String) {
            try {
                val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun openContacts() {
            try {
                val i = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun autoStatus(): String {
            val o = JSONObject()
            try {
                val pm = packageManager
                val svc = pm.queryIntentServices(Intent("androidx.car.app.CarAppService"), 0)
                var declared = false
                for (r in svc) {
                    if (r.serviceInfo != null && r.serviceInfo.packageName == packageName) declared = true
                }
                o.put("serviceDeclared", declared)
                val info = pm.getPackageInfo(packageName, 0)
                o.put("version", info.versionName ?: "")
                o.put("versionCode", info.versionCode)
                var gh = ""
                try {
                    val g = pm.getPackageInfo("com.google.android.projection.gearhead", 0)
                    gh = g.versionName ?: "?"
                } catch (e: Exception) {
                }
                o.put("androidAuto", gh)
            } catch (e: Exception) {
                o.put("error", e.toString())
            }
            o.put("hostAt", NavState.hostAt)
            o.put("sessionAt", NavState.sessionAt)
            return o.toString()
        }

        @JavascriptInterface
        fun carState(json: String) {
            try {
                NavState.update(json)
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun fetchText(id: String, url: String) {
            thread {
                var text: String? = null
                var err = ""
                try {
                    var u = url
                    var hop = 0
                    while (hop < 6 && text == null) {
                        val c = URL(u).openConnection() as HttpURLConnection
                        c.instanceFollowRedirects = false
                        c.connectTimeout = 12000
                        c.readTimeout = 30000
                        c.setRequestProperty("User-Agent", "GPS-app/2.0")
                        c.setRequestProperty("Accept", "application/xml,text/xml,*/*")
                        val code = c.responseCode
                        if (code in 300..399) {
                            val loc = c.getHeaderField("Location")
                            c.disconnect()
                            if (loc == null) throw IOException("redirection sans adresse")
                            u = URL(URL(u), loc).toString()
                            hop++
                            continue
                        }
                        if (code != 200) throw IOException("HTTP $code")
                        val out = ByteArrayOutputStream()
                        val buf = ByteArray(16384)
                        var total = 0
                        c.inputStream.use { input ->
                            while (true) {
                                val n = input.read(buf)
                                if (n <= 0) break
                                total += n
                                if (total > 8000000) throw IOException("fichier trop gros")
                                out.write(buf, 0, n)
                            }
                        }
                        c.disconnect()
                        text = out.toString("UTF-8")
                    }
                    if (text == null) throw IOException("trop de redirections")
                } catch (e: Exception) {
                    err = e.message ?: "erreur"
                }
                val js = "window.__nat&&window.__nat(" + JSONObject.quote(id) + "," +
                    (if (text == null) "null" else JSONObject.quote(text)) + "," + JSONObject.quote(err) + ")"
                runOnUiThread { wv.evaluateJavascript(js, null) }
            }
        }
    }
}
