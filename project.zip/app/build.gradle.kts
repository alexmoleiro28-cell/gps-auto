plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pauloburg.gps"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pauloburg.gps"
        minSdk = 23
        targetSdk = 34
        versionCode = 3
        versionName = "2.1"
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("k.jks")
            storePassword = "gpsgps123"
            keyAlias = "gps"
            keyPassword = "gpsgps123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.car.app:app:1.4.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-common:2.8.4")
}
